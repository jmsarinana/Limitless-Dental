export const GQL_ACF_TYPOGRAPHY = ( prefix ) => `
  ${prefix}FontFamily
  ${prefix}FontSize
  ${prefix}FontWeight
  ${prefix}LetterSpacing
  ${prefix}LineHeight
  ${prefix}TextTransform
`
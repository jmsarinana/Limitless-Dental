const colors = {
  black:   '#000000',
  white:   '#ffffff',
  gray:    '#646464',
  xltgray: '#efefef',
  ltgray:  '#d9d9d9',
  dkgray:  '#3a3a3a',
}

export default colors
